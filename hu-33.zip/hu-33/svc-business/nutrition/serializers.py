from rest_framework import serializers
from rest_framework.validators import UniqueValidator
from django.utils import timezone
from decimal import Decimal, ROUND_HALF_UP
from django.db import transaction
from datetime import date

from .models import (
    NutritionalProfile,
    Food,
    FoodCategory,
    FoodNutrient,
    ConsumptionRecord,
    ConsumptionItem
)


class NutritionalProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = NutritionalProfile
        fields = [
            "id",
            "user_id",
            "date_of_birth",
            "sex",
            "weight",
            "height",
            "activity_level",
            "created_at",
            "updated_at"
        ]
        read_only_fields = [
            "id",
            "created_at",
            "updated_at"
        ]

    def validate_date_of_birth(self, value):
        today = date.today()

        if value > today:
            raise serializers.ValidationError(
                "Date of birth cannot be in the future"
            )

        age = today.year - value.year
        if (today.month, today.day) < (value.month, value.day):
            age -= 1

        if age < 1 or age > 120:
            raise serializers.ValidationError(
                "Age must be between 1 and 120 years."
            )

        return value

    def validate_weight(self, value):
        if value <= 0:
            raise serializers.ValidationError(
                "Weight must be greater than 0."
            )
        return value

    def validate_height(self, value):
        if value <= 0:
            raise serializers.ValidationError(
                "Height must be greater than 0."
            )

        return value


class FoodCategorySerializer(serializers.ModelSerializer):
    name = serializers.CharField(
        allow_blank=True,
        validators=[
            UniqueValidator(
                queryset=FoodCategory.objects.all(),
                lookup="iexact",
                message="A category with this name already exists."
            )
        ]
    )

    description = serializers.CharField(
        allow_blank=True
    )

    class Meta:
        model = FoodCategory
        fields = [
            "id",
            "name",
            "description"
        ]
        read_only_fields = [
            "id"
        ]

    def validate_name(self, value):
        if not value.strip():
            raise serializers.ValidationError(
                "The category name cannot be empty."
            )

        return value.strip().upper()

    def validate_description(self, value):
        if not value.strip():
            raise serializers.ValidationError(
                "The description of a category cannot be empty."
            )

        return value.strip().upper()


class FoodNutrientSerializer(serializers.ModelSerializer):
    class Meta:
        model = FoodNutrient
        fields = [
            "id",
            "nutrient_type",
            "amount",
            "unit"
        ]
        read_only_fields = [
            "id"
        ]

    def validate_amount(self, value):
        if value < 0:
            raise serializers.ValidationError(
                "La cantidad del nutriente no puede ser negativa."
            )

        return value


class FoodSerializer(serializers.ModelSerializer):
    # Expose the foreign key as category_id in the API
    category_id = serializers.PrimaryKeyRelatedField(
        source="category",
        queryset=FoodCategory.objects.all()
    )

    name = serializers.CharField(
        allow_blank=True,
        validators=[
            UniqueValidator(
                queryset=Food.objects.all(),
                lookup="iexact",
                message="There is already a food product with this name."
            )
        ]
    )

    description = serializers.CharField(
        allow_blank=True
    )

    nutrients = FoodNutrientSerializer(
        many=True,
        allow_empty=False
    )

    class Meta:
        model = Food
        fields = [
            "id",
            "category_id",
            "name",
            "description",
            "serving_size",
            "serving_unit",
            "nutrients",
            "created_at",
            "updated_at"
        ]
        read_only_fields = [
            "id",
            "created_at",
            "updated_at"
        ]

    def validate_nutrients(self, value):
        nutrient_types = [
            nutrient["nutrient_type"]
            for nutrient in value
        ]

        if len(nutrient_types) != len(set(nutrient_types)):
            raise serializers.ValidationError(
                "Repeating the type of nutrient in a food item is not permitted."
            )

        return value

    def validate_name(self, value):
        if not value.strip():
            raise serializers.ValidationError(
                "El nombre del alimento no puede estar vacío."
            )

        return value.strip().upper()

    def validate_description(self, value):
        if not value.strip():
            raise serializers.ValidationError(
                "The description cannot be empty."
            )

        return value.strip().upper()

    def validate_serving_size(self, value):
        if value != 100:
            raise serializers.ValidationError(
                "The serving size must be exactly 100."
            )

        return value

    def create(self, validated_data):
        # Extract nutrients because they belong to FoodNutrient, not Food.
        nutrients_data = validated_data.pop("nutrients")

        # Create the food before creating its related nutrinets.
        food = Food.objects.create(**validated_data)

        # Associate each nutrient with the newly created food.
        for nutrient_data in nutrients_data:
            FoodNutrient.objects.create(
                food=food,
                **nutrient_data
            )

        return food

    def update(self, instance, validated_data):
        nutrients_data = validated_data.pop("nutrients", None)

        # Update the food fields.
        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        instance.save()

        # Replace the existing nutrients when provided.
        if nutrients_data is not None:
            instance.nutrients.all().delete()

            for nutrient_data in nutrients_data:
                FoodNutrient.objects.create(
                    food=instance,
                    **nutrient_data
                )

        return instance


class FoodReadSerializer(serializers.ModelSerializer):
    category = FoodCategorySerializer(read_only=True)
    nutrients = FoodNutrientSerializer(
        many=True,
        read_only=True
    )

    class Meta:
        model = Food
        fields = [
            "id",
            "category",
            "name",
            "description",
            "serving_size",
            "serving_unit",
            "nutrients",
            "created_at",
            "updated_at"
        ]


class ConsumptionItemSerializer(serializers.ModelSerializer):
    food_id = serializers.PrimaryKeyRelatedField(
        source="food",
        queryset=Food.objects.all()
    )

    class Meta:
        model = ConsumptionItem
        fields = [
            "id",
            "food_id",
            "quantity",
            "calories",
            "protein",
            "carbohydrates",
            "fat",
            "fiber",
            "sugar",
            "sodium"
        ]

        read_only_fields = [
            "id",
            "calories",
            "protein",
            "carbohydrates",
            "fat",
            "fiber",
            "sugar",
            "sodium"
        ]

    def get_fields(self):
        fields = super().get_fields()

        for field_name in [
            "calories",
            "protein",
            "carbohydrates",
            "fat",
            "fiber",
            "sugar",
            "sodium"
        ]:
            fields[field_name].required = False

        return fields

    def validate_quantity(self, value):
        if value <= 0:
            raise serializers.ValidationError(
                "Quantity must be greater than zero."
            )

        return value


class ConsumptionRecordSerializer(serializers.ModelSerializer):
    consumption_items = ConsumptionItemSerializer(
        many=True,
        allow_empty=False
    )
    notes = serializers.CharField(
        allow_blank=True
    )

    class Meta:
        model = ConsumptionRecord
        fields = [
            "id",
            "user_id",
            "consumed_at",
            "notes",
            "consumption_items",
            "created_at",
        ]
        read_only_fields = [
            "id",
            "created_at"
        ]

    def validate_consumed_at(self, value):
        if value > timezone.now():
            raise serializers.ValidationError(
                "Consumption date and time cannot be in the future"
            )

        return value

    def validate_notes(self, value):
        return value.strip().upper()

    def create(self, validated_data):
        items_data = validated_data.pop("consumption_items")

        with transaction.atomic():
            record = ConsumptionRecord.objects.create(**validated_data)

            for item_data in items_data:
                food = item_data["food"]
                quantity = item_data["quantity"]

                nutrients = {
                    nutrient.nutrient_type: nutrient
                    for nutrient in food.nutrients.all()
                }

                def calculate_nutrient(nutrient_type):
                    nutrient = nutrients.get(nutrient_type)

                    if nutrient is None:
                        raise serializers.ValidationError({
                            "consumption_items": (
                                f"Food '{food.name}' is missing "
                                f"the nutrient '{nutrient_type}'"
                            )
                        })

                    expected_unit = (
                        "KCAL" if nutrient_type == "CALORIES"
                        else "MG" if nutrient_type == "SODIUM"
                        else "G"
                    )

                    if nutrient.unit != expected_unit:
                        raise serializers.ValidationError({
                            "consumption_items": (
                                f"Food '{food.name}' has an invalid unit "
                                f"for nutrient '{nutrient_type}'. "
                                f"Expected '{expected_unit}'."
                            )
                        })

                    return (
                        (nutrient.amount * quantity / Decimal("100"))
                        .quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                    )

                nutrition_data = {
                    "calories": calculate_nutrient("CALORIES"),
                    "protein": calculate_nutrient("PROTEIN"),
                    "carbohydrates": calculate_nutrient("CARBOHYDRATES"),
                    "fat": calculate_nutrient("FAT"),
                    "fiber": calculate_nutrient("FIBER"),
                    "sugar": calculate_nutrient("SUGAR"),
                    "sodium": calculate_nutrient("SODIUM")
                }

                ConsumptionItem.objects.create(
                    consumption=record,
                    food=food,
                    quantity=quantity,
                    **nutrition_data
                )

        return record


class ConsumptionItemReadSerializer(serializers.ModelSerializer):
    food = serializers.CharField(
        source="food.name",
        read_only=True
    )

    serving_unit = serializers.CharField(
        source="food.serving_unit",
        read_only=True
    )

    class Meta:
        model = ConsumptionItem
        fields = [
            "id",
            "food",
            "quantity",
            "serving_unit",
            "calories",
            "protein",
            "carbohydrates",
            "fat",
            "fiber",
            "sugar",
            "sodium"
        ]


class ConsumptionHistorySerializer(serializers.ModelSerializer):
    consumption_items = ConsumptionItemReadSerializer(
        many=True,
        read_only=True
    )

    class Meta:
        model = ConsumptionRecord
        fields = [
            "id",
            "consumed_at",
            "notes",
            "consumption_items",
            "created_at"
        ]
